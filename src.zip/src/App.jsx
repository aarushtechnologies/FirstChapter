function App() {
  return (
    <>
      <div>
        <font color="red" size='7'>JSX</font>
        <h1>Hello Codingwale - Vaijapur</h1>
        <h2>Pankaj Tribhuvan</h2>
      </div>
      <hr />
      <div>
        <h1>Hello Codingwale - Vaijapur</h1>
        <h2>Pankaj Tribhuvan</h2>
      </div>
    </>

  )
}

export default App