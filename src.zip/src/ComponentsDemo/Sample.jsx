function Sample1()
{
    return (
        <>
        <h1>Sample 1</h1>
        </>
    )
}

function Sample2()
{
    return (
        <>
        <h1>Sample 2</h1>
        </>
    )
}

function Sample3()
{
    return (
        <>
        <h1>Sample 3</h1>
        </>
    )
}

export  {Sample1,Sample2,Sample3}