function Demo()
{
    return (
        <>
        <h1>Demo Component</h1>
        </>
    );
}
//functional Component
export default Demo;